local function w(a,t,e)
local t=io.open(t,'w+')
local o=e:len()
for a in io.lines(a)do
if a:sub(1,o)~=e then
t:write(a,'\n')
end
end
return t
end
local function d(t,e,...)
if not e then
return t
end
return d(t.."'"..string.gsub(e,"'","'\\''").."' ",...)
end
local f=io
local s=os
local a=string
local h=tonumber
local m=ipairs
local u=table
local o=require'nixio'
local c=require'hash'
local i=require'gluon.sysconfig'
local r=require'gluon.site_config'
local n=require('luci.model.uci').cursor()
local l=require'luci.util'
local t=require'nixio.fs'
module'gluon.util'
function exec(...)
return s.execute(d('','exec',...))
end
function replace_prefix(e,t,o)
local a=e..'.tmp'
local t=w(e,a,t)
if o then
t:write(o)
end
t:close()
s.rename(a,e)
end
function readline(e)
local t=e:read('*l')
e:close()
return t
end
function lock(e)
exec('lock',e)
end
function unlock(e)
exec('lock','-u',e)
end
function node_id()
return a.gsub(i.primary_mac,':','')
end
local function d(e)
for e in t.glob('/sys/devices/'..e..'/ieee80211/phy*')do
return e:match('([^/]+)$')
end
end
local function s(e)
local a=e:lower()
for e in t.glob('/sys/class/ieee80211/*/macaddress')do
if l.trim(t.readfile(e))==a then
return e:match('([^/]+)/macaddress$')
end
end
end
local function t(e)
local e=n:get_all('wireless',e)
if not e or e.type~='mac80211'then
return nil
elseif e.path then
return d(e.path)
elseif e.macaddr then
return s(e.macaddr)
else
return nil
end
end
local function l(e)
local e=t(e)
if not e then
return function()end
end
return f.lines('/sys/class/ieee80211/'..e..'/addresses')
end
function generate_mac(n)
if n>7 or n<0 then return nil end
local e=a.sub(c.md5(i.primary_mac),0,12)
local t,i,s,d,r,e=a.match(e,'(%x%x)(%x%x)(%x%x)(%x%x)(%x%x)(%x%x)')
t=h(t,16)
e=h(e,16)
t=o.bit.bor(t,2)
t=o.bit.band(t,254)
e=o.bit.band(e,248)
e=e+n
return a.format('%02x:%s:%s:%s:%s:%02x',t,i,s,d,r,e)
end
local function s(t,o)
local a=i.primary_mac:lower()
local e=1
for t in l(t)do
if t:lower()~=a then
if e==o then
return t
end
e=e+1
end
end
end
function get_wlan_mac(e,a,t)
local e=s(e,t)
if e then
return e
end
return generate_mac(4*(a-1)+(t-1))
end
function iterate_radios(o)
local e={}
n:foreach('wireless','wifi-device',
function(t)
u.insert(e,t['.name'])
end
)
for a,t in m(e)do
local e=n:get('wireless',t,'hwmode')
if e=='11g'or e=='11ng'then
o(t,a,r.wifi24)
elseif e=='11a'or e=='11na'then
o(t,a,r.wifi5)
end
end
end
