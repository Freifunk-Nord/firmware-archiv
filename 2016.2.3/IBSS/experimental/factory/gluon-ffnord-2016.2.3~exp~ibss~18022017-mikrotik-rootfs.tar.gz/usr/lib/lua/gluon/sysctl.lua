local t=require'gluon.util'
module'gluon.sysctl'
function set(e,a)
t.replace_prefix('/etc/sysctl.conf',e..'=',e..'='..a..'\n')
end
