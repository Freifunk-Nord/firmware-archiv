local function o()
local t='/lib/gluon/site.json'
local a=require'luci.jsonc'
local e=require'luci.ltn12'
local t=assert(io.open(t))
local a=a.new()
e.pump.all(e.source.file(t),a:sink())
t:close()
return assert(a:get())
end
local e=setmetatable
module'gluon.site_config'
e(_M,
{
__index=o(),
}
)
return _M
