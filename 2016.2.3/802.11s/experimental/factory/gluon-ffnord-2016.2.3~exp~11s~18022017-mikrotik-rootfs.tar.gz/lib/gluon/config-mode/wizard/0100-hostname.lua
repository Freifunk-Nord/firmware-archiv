local a=require"luci.cbi"
local i=require"luci.i18n"
local o=require"pretty_hostname"
local t=luci.model.uci.cursor()
local e={}
function e.section(e)
local e=e:section(a.SimpleSection,nil,nil)
local e=e:option(a.Value,"_hostname",i.translate("Node name"))
e.value=o.get(t)
e.rmempty=false
e.datatype="hostname"
end
function e.handle(e)
o.set(t,e._hostname)
t:commit("system")
end
return e
