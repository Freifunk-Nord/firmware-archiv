local a="/lib/gluon/config-mode/wizard/"
local e=luci.i18n
local e=luci.model.uci.cursor()
local i=require"nixio.fs"
local n=require"nixio.util"
local e,t
local t={}
local o={}
if i.access(a)then
o=n.consume(i.dir(a))
table.sort(o)
end
for i,o in ipairs(o)do
if o:sub(1,1)~='.'then
table.insert(t,dofile(a..'/'..o))
end
end
e=SimpleForm("wizard")
e.reset=false
e.template="gluon/cbi/config-mode"
for a,t in ipairs(t)do
t.section(e)
end
function e.handle(o,a,e)
if a==FORM_VALID then
for a,t in ipairs(t)do
t.handle(e)
end
luci.http.redirect(luci.dispatcher.build_url("gluon-config-mode","reboot"))
end
return true
end
return e
