module("luci.controller.admin.portconfig",package.seeall)
function index()
entry({"admin","portconfig"},cbi("admin/portconfig"),_("Network"),20)
end
