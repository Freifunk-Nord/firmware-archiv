local t=luci.model.uci.cursor()
local s=require'gluon.util'
local a,o,e,i
local i='wan_radio0'
local n=t:get('wireless',i,"ssid")
a=SimpleForm("wifi",translate("Private WLAN"))
a.template="admin/expertmode"
o=a:section(SimpleSection,nil,translate(
'Your node can additionally extend your private network by bridging the WAN interface '
..'with a separate WLAN. This feature is completely independent of the mesh functionality. '
..'Please note that the private WLAN and meshing on the WAN interface should not be enabled '
..'at the same time.'
))
e=o:option(Flag,"enabled",translate("Enabled"))
e.default=(n and not t:get_bool('wireless',i,"disabled"))and e.enabled or e.disabled
e.rmempty=false
e=o:option(Value,"ssid",translate("Name (SSID)"))
e:depends("enabled",'1')
e.datatype="maxlength(32)"
e.default=n
e=o:option(Value,"key",translate("Key"),translate("8-63 characters"))
e:depends("enabled",'1')
e.datatype="wpakey"
e.default=t:get('wireless',i,"key")
function a.handle(o,e,a)
if e==FORM_VALID then
s.iterate_radios(
function(e,i)
local o="wan_"..e
if a.enabled=='1'then
local i=s.get_wlan_mac(e,i,4)
t:section('wireless',"wifi-iface",o,
{
device=e,
network="wan",
mode='ap',
encryption='psk2',
ssid=a.ssid,
key=a.key,
macaddr=i,
disabled=0,
}
)
else
t:set('wireless',o,"disabled",1)
end
end
)
t:save('wireless')
t:commit('wireless')
end
end
return a
