local i=require"os"
local n=require"io"
local a=require"nixio.fs"
local e=require"luci.util"
local d=type
local t=pairs
local h=error
local e=table
local s="opkg --force-removal-of-dependent-packages --force-overwrite --nocase"
local r="/etc/opkg.conf"
module"luci.model.ipkg"
local function o(o,...)
local e=""
for a,t in t({...})do
e=e.." '"..t:gsub("'","").."'"
end
local e="%s %s %s >/tmp/opkg.stdout 2>/tmp/opkg.stderr"%{s,o,e}
local o=i.execute(e)
local e=a.readfile("/tmp/opkg.stderr")
local t=a.readfile("/tmp/opkg.stdout")
a.unlink("/tmp/opkg.stderr")
a.unlink("/tmp/opkg.stdout")
return o,t or"",e or""
end
local function l(t)
if d(t)~="function"then
h("OPKG: Invalid rawdata given")
end
local n={}
local e={}
local o=nil
for i in t do
if i:sub(1,1)~=" "then
local a,t=i:match("(.-): ?(.*)%s*")
if a and t then
if a=="Package"then
e={Package=t}
n[t]=e
elseif a=="Status"then
e.Status={}
for t in t:gmatch("([^ ]+)")do
e.Status[t]=true
end
else
e[a]=t
end
o=a
end
else
e[o]=e[o].."\n"..i
end
end
return n
end
local function h(e,t)
local e=s.." "..e
if t then
e=e.." '"..t:gsub("'","").."'"
end
local t=i.tmpname()
i.execute(e..(" >%s 2>/dev/null"%t))
local e=l(n.lines(t))
i.remove(t)
return e
end
function info(e)
return h("info",e)
end
function status(e)
return h("status",e)
end
function install(...)
return o("install",...)
end
function installed(e)
local e=status(e)[e]
return(e and e.Status and e.Status.installed)
end
function remove(...)
return o("remove",...)
end
function update()
return o("update")
end
function upgrade()
return o("upgrade")
end
function _list(t,e,h)
local n=n.popen(s.." "..t..
(e and(" '%s'"%e:gsub("'",""))or""))
if n then
local t,e,a,o
while true do
local i=n:read("*l")
if not i then break end
t,e,a,o=i:match("^(.-) %- (.-) %- (.-) %- (.+)")
if not t then
t,e,a=i:match("^(.-) %- (.-) %- (.+)")
o=""
end
if t and e then
if#e>26 then
e=e:sub(1,21)..".."..e:sub(-3,-1)
end
h(t,e,a,o)
end
t=nil
e=nil
a=nil
o=nil
end
n:close()
end
end
function list_all(e,t)
_list("list --size",e,t)
end
function list_installed(t,e)
_list("list_installed --size",t,e)
end
function find(t,e)
_list("find --size",t,e)
end
function overlay_root()
local t="/"
local o=n.open(r,"r")
if o then
local e
repeat
e=o:read("*l")
if e and e:match("^%s*option%s+overlay_root%s+")then
t=e:match("^%s*option%s+overlay_root%s+(%S+)")
local e=a.stat(t)
if not e or e.type~="dir"then
t="/"
end
break
end
until not e
o:close()
end
return t
end
