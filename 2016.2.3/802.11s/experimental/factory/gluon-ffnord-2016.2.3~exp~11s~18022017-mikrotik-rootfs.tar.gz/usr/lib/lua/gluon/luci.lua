local e=string
module'gluon.luci'
function escape(t)
return(e.gsub(t,'[<>&"]',{
['<']='&lt;',
['>']='&gt;',
['&']='&amp;',
['"']='&quot;',
}))
end
function urlescape(t)
return(e.gsub(t,'[^a-zA-Z0-9%-_%.~]',
function(a)
local t=''
for o=1,e.len(a)do
t=t..e.format('%%%02X',e.byte(a,o,o))
end
return t
end
))
end
